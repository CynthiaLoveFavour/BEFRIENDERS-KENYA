require("../models/SupportGroup")();
require("../models/MyGroups")();
const pool = require("../database/ConnectionString");
const {
  validateSupportGroup
} = require("../validations/SupportGrouprofileValidation");

class SupportGroupController {
    static async createSupportGroup(request, response) {
        
        console.log(request.body)

        const {
            community_title,
            community_contact,
            community_description,
            community_slogan,
            community_joining_fee,
            community_platform
        } = request.body;

        const postResponse = await pool.query(
        `INSERT INTO support_groups(community_title, community_contact, community_description, community_slogan, community_joining_fee, community_platform)
            VALUES($1, $2, $3, $4, $5, $6)`,[community_title, community_contact, community_description, community_slogan, community_joining_fee, community_platform] );
        if (postResponse.rowCount == 0) {
        return response
            .status(400)
            .json({ message: "Request unsuccessful. Save failed" });
        } else {
        return response
            .status(200)
            .json({ message: "Group created succesfuly!" });
        }
    }

    static async getAllSupportGroup(request, response) {
        const groups = await pool.query(`SELECT * FROM support_groups`);
        if (groups.rowCount === 0) {
        return response.status(200).json({ message: "No grpous found" });
        } else {
        return response.status(200).json(groups.rows);
        }
    }

    static async getSupportGroupPayment(request, response) {
        const group = await pool.query(
            `SELECT * FROM my_groups 
            LEFT JOIN support_groups
            ON support_groups.support_group_id=my_groups.support_group_id
            LEFT JOIN users
            ON users.socket_auth_users_public_id=my_groups.public_id  `
            );
    
            
            return response.status(200).json(group.rows);
            
    }

    static async getMySupportGroup(request, response) {
        const public_id = request.params.id;
        const group = await pool.query(
        `SELECT * FROM my_groups 
        LEFT JOIN support_groups
        ON support_groups.support_group_id=my_groups.support_group_id
        WHERE public_id='${public_id}'`
        );
            console.log(group)
        if (group.rowCount === 0) {
        return response.status(200).json(group.rows);
        } else {
        return response.status(200).json(group.rows);
        }
    }

    static async deleteOneSupportGroup(request, response) {
        const support_group_id = request.params.id;
        const group = await pool.query(
        `DELETE FROM support_groups WHERE support_group_id='${support_group_id}'`
        );
        if (group.rowCount == 0) {
        return response
            .status(400)
            .json({ message: "Request unsuccessful. delete failed" });
        } else {
        return response.status(200).json({ message: "Group deleted succesfuly" });
        }
    }

    static async joinOneSupportGroup(request, response) {
        const { public_id, support_group_id } = request.body;
        // check if user is in group
        const user = await pool.query(`SELECT * FROM my_groups WHERE public_id=$1 AND support_group_id=$2 `, [public_id, support_group_id]);

        if (user.rows.length === 0) {
            const postResponse = await pool.query(`INSERT INTO my_groups(public_id, support_group_id) VALUES($1, $2)`, [public_id, support_group_id]);
            if (postResponse.rowCount == 0) {
                return response
                .status(400)
                .json({ message: "Request unsuccessful. Save failed" });
            } else {
                return response
                .status(200)
                .json({ message: "Added to community succesfuly!" });
            }
        } else {
            return response
                .status(200)
                .json({ message: "Sorry support group already joined!" });
        }
    }

    static async makePaymntToGroup(request, response) {
        const my_groups_id=request.params.id;
        const {price} = request.body;
        console.log(request.body)
        console.log(my_groups_id)
        
            const leave = await pool.query(`UPDATE my_groups SET price='${price}'
            WHERE my_groups_id='${my_groups_id}'`);
            if (leave.rowCount == 0) {
            return response
                .status(400)
                .json({ message: "Request unsuccessful." });
            } else {
            return response.status(200).json({ message: "Payment added to data" });
            }
    }

    static async leaveOneSupportGroup(request, response) {
        const my_groups_id = request.params.id;
            const leave = await pool.query(
            `DELETE FROM my_groups WHERE my_groups_id='${my_groups_id}'`
            );
            if (leave.rowCount == 0) {
            return response
                .status(400)
                .json({ message: "Request unsuccessful. delete failed" });
            } else {
            return response.status(200).json({ message: "Group deleted succesfuly" });
            }
    }
}

module.exports = SupportGroupController;
