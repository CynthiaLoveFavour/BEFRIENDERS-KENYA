require('../models/Tweets')();
const pool = require('../database/ConnectionString');
// const {validateUserProfile, validateUserProfileUpdate} = require('../validations/UserProfilerofileValidation');
const data = require('../dataset/tweets.json');
const fs = require('fs')

class UserProfileController {
    

    static async crawlAndSaveTwits(request, response) {
        let obj = require("../dataset/tweets.json");

        let jsondata = obj;
            console.log(jsondata.length);
            for (var i = 0; i < jsondata.length; i++) {
            const postResponse = pool.query(
                `INSERT INTO tweets(Client, Name, ProfileURL, TweetContent, TweetId, TweetURL, UserId, Username) 
                VALUES('${jsondata[i].Client}', '${jsondata[i].Name}', '${jsondata[i].ProfileURL}', '${jsondata[i].TweetContent}', '${jsondata[i].TweetId}', '${jsondata[i].TweetURL}', '${jsondata[i].UserId}', '${jsondata[i].Username}')`);
            }
            // return response
            // .status(200)
            // .json({ message: "Products created succesfuly!" });
            // return response.status(200).json(data);

        return response.status(200).json(obj);
    };

    static async GetAllTweets(request, response) {
        const tweete = await pool.query("SELECT * FROM tweets");
        return response.status(200).json(tweete.rows);
    };

    static async updateUserProfileImage(request, response) {
        const socket_auth_users_public_id = request.params.id;
        const socket_auth_user_file = request.file.path;

        const sqlUpdateRequest = `UPDATE user_profile SET  socket_auth_user_file='${socket_auth_user_file}' WHERE socket_auth_users_public_id='${socket_auth_users_public_id}' `;
        
        await pool.query(sqlUpdateRequest);
        return response.status(201).json({ message: 'Uploaded' });
    };


    static async getUserProfile(request, response) {
        const socket_auth_users_public_id = request.params.id;
        const sqlFetchRequest = `SELECT * FROM user_profile JOIN users ON user_profile.socket_auth_users_public_id=users.socket_auth_users_public_id WHERE user_profile.socket_auth_users_public_id='${socket_auth_users_public_id}'`;
        
        const profile = await pool.query(sqlFetchRequest);
        return response.status(200).json(profile.rows);
    }

    static async updateUserPaypalEmailProfile(request, response) {
        const socket_auth_users_public_id = request.params.id;

        const {socket_auth_user_paypal_email } = request.body;
        const sqlUpdateRequest = `UPDATE user_profile SET socket_auth_user_paypal_email='${socket_auth_user_paypal_email}'  WHERE socket_auth_users_public_id='${socket_auth_users_public_id}'`;

        await pool.query(sqlUpdateRequest);
        return response.status(200).json({ message: 'Paypal email updated succesfuly'});
    }   

}; 

module.exports = UserProfileController;