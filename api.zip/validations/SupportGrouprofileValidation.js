const Joi = require("@hapi/joi");

const validateSupportGroup = user => {
  const schema = Joi.object().keys({
    community_title: Joi.string()
      .min(10)
      .required()
      .label("Title"),
      community_contact: Joi.string()
      .required()
      .label("Contact"),
      community_description: Joi.string()
      .required()
      .label("Description"),
      community_slogan: Joi.string()
      .required()
      .label("Slogan"),
      community_joining_fee: Joi.string()
      .required()
      .label("Slogan"),
      community_platform: Joi.string()
      .required()
      .label("Slogan") 
  });

  return schema.validate(user);
};
module.exports = { validateSupportGroup };
