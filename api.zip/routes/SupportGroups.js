// SupportGroups.js
const express = require("express");
const router = express.Router();
const SupportGroupsController = require('../controllers/SupportGroupsController');
const authenticate = require('../middleware/auth');

router.post('/v1/', SupportGroupsController.createSupportGroup);
router.get('/v1/', SupportGroupsController.getAllSupportGroup);
router.get('/v1/payments/', SupportGroupsController.getSupportGroupPayment);
router.get('/v1/:id', SupportGroupsController.getMySupportGroup);
router.post('/v1/join/', SupportGroupsController.joinOneSupportGroup);
router.patch('/v1/payment/:id', SupportGroupsController.makePaymntToGroup);

module.exports = router;