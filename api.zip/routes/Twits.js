const express = require("express");
const router = express.Router();
const TwitsController = require('../controllers/TwitsController');
const authenticate = require('../middleware/auth');

router.get('/v1/tweets/', TwitsController.crawlAndSaveTwits);
router.get('/v1/', TwitsController.GetAllTweets);
// router.patch('/image/v1/:id', authenticate, upload.single('socket_auth_user_file'), TwitsController.updateUserProfileImage);
// router.get('/v1/:id', TwitsController.getUserProfile);
// router.patch('/paypalemail/v1/:id', authenticate, TwitsController.updateUserPaypalEmailProfile);

module.exports = router;