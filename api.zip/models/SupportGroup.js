const pool = require('../database/ConnectionString');

const createSupportGroupTable = async () => {
    try { 
        await pool.query(`
            CREATE TABLE IF NOT EXISTS support_groups(
                support_group_id SERIAL,
                community_title TEXT NOT NULL,
                community_contact TEXT NOT NULL,
                community_description TEXT NOT NULL,
                community_slogan TEXT NOT NULL,
                community_joining_fee TEXT NOT NULL,
                community_platform TEXT NULL,
                time_created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
        `);
    } catch (error) {
        console.log(error);
    };
}
createSupportGroupTable();

module.exports = createSupportGroupTable; 