const pool = require('../database/ConnectionString');

const createMyGroupsTable = async () => {
    try { 
        await pool.query(`
            CREATE TABLE IF NOT EXISTS my_groups(
                my_groups_id SERIAL,
                public_id VARCHAR(255) NULL,
                support_group_id INTEGER NULL,
                price VARCHAR(50) NULL,
                paid BOOLEAN DEFAULT false NULL,
                time_created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
        `);
    } catch (error) {
        console.log(error);
    };
}
createMyGroupsTable();

module.exports = createMyGroupsTable;