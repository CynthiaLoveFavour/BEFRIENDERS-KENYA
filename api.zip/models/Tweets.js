const pool = require('../database/ConnectionString');

const createTweetsTable = async () => {
    try { 
        await pool.query(`
            CREATE TABLE IF NOT EXISTS tweets(
                tweets_id SERIAL,
                Client TEXT NOT NULL,
                Name TEXT NOT NULL,
                ProfileURL TEXT NOT NULL,
                TweetContent TEXT NOT NULL,
                TweetId TEXT NOT NULL,
                TweetURL TEXT NOT NULL,
                UserId TEXT NOT NULL,
                Username TEXT NOT NULL,
                time_created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
        `);
    } catch (error) {
        console.log(error);
    };
}
createTweetsTable();

module.exports = createTweetsTable; 