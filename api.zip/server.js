const express = require("express");
const path = require('path')
const cors = require('cors');
const app = express();
const helmet = require("helmet");
const compression = require("compression");
const bodyParser = require("body-parser");
const error = require("./middleware/error");
require("dotenv").config();
require("express-async-errors");

app.set('view engine', 'ejs');
app.get('/', (request, response) => response.render('index'));

const registration = require("./routes/UserRegistration");
const auth = require("./routes/Auth");
const profile = require("./routes/UserProfile");
const tweets = require("./routes/Twits");
const supportGroups = require("./routes/SupportGroups");

app.use(cors());
app.options('*', cors())

app.use(bodyParser.json());
app.use(express.json());
app.use(helmet());
app.use(compression());
app.use("/uploads", express.static('uploads'));
app.use("/api/registration", registration);
app.use("/api/auth", auth);
app.use("/api/profile", profile);
app.use("/api/tweets", tweets);
app.use("/api/supportGroups", supportGroups);

app.use(error);
const port = 2500 ;
const server = app.listen(`${port}`);
 